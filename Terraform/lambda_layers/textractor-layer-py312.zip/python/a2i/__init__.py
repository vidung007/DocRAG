# -*- coding: utf-8 -*-
"""Top-level package for amazon-textract-response-parser."""

__version__ = '1.0.2'

__version__ = "1.9.2"

from .textractor import Textractor
